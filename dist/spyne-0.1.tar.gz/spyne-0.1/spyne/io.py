# ================================================================== #
# READ/WRITE
# ================================================================== #
# (Still unfinished) Code for reading and writing persistent models
# ================================================================== #


import neural as n

def WriteString(s, file=f):
    """
    A string is written as an integer N (specifying the length)
    and a set of N unicode characters
    """
    pass

def WriteProjection(p, file=f):
    f.write("%P:")
    f.read()
